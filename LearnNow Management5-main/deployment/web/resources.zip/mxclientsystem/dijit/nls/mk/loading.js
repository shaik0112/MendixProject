//>>built
define("dijit/nls/mk/loading",{loadingState:"Вчитување...",errorState:"Се појави грешка"});
